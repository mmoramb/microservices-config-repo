package com.example.zipkingsleuth1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zipkingsleuth1Application {

	public static void main(String[] args) {
		SpringApplication.run(Zipkingsleuth1Application.class, args);
	}

}
