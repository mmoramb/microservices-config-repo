package com.example.zipkingsleuth1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zipkingsleuth1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
