package com.example.zipkingsleuth4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zipkingsleuth4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
