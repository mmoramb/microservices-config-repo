package com.example.zipkingsleuth4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zipkingsleuth4Application {

	public static void main(String[] args) {
		SpringApplication.run(Zipkingsleuth4Application.class, args);
	}

}
